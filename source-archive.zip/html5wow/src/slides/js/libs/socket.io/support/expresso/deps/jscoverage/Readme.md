# node-jscoverage

   [JScoverage](http://siliconforks.com/jscoverage/) for node.

## Installation

    $ ./configure && make && make install

