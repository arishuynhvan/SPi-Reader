window.config = window.config || {
  disableBuilds: false,
  disableCodeHighlights: false,
  disableNotes: false,
  disablePrettyprint: false,
  enableWebSockets: false
};