$(document).ready(function() {
   
   initReflections();
   initUi();

   $(".emaillink").defuscate_mailto();
   $(".emailtext").defuscate();
    
});